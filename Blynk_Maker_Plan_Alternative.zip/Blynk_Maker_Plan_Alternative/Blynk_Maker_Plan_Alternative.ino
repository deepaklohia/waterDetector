#define BLYNK_TEMPLATE_ID "abcd"
#define BLYNK_TEMPLATE_NAME "M1 MOTOR"
#define BLYNK_FIRMWARE_VERSION "0.0.1"

/*
9-11-2025 Added Blynk Message , added time stamp
*/

//#define BLYNK_PRINT Serial
//#define BLYNK_DEBUG
//#define APP_DEBUG

// Uncomment your board, or configure a custom board in Settings.h
//#define USE_SPARKFUN_BLYNK_BOARD
//#define USE_NODE_MCU_BOARD
//#define USE_WITTY_CLOUD_BOARD
#define USE_WEMOS_D1_MINI

#define VPIN_TEMP_OFF       	V0
#define VPIN_MOTOR_STATUS     V1
#define VPIN_SV_VALUE         V2
#define VPIN_SV_LIMIT         V3
//#define VPIN_SEPTIC_TANK    V4
#define VPIN_INFO             V5
#define VPIN_FORCE_START      V6
#define VPIN_WAIT_BEFORE_OFF  V7
#define VPIN_TEMP_RUN_MIN     V8
#define VPIN_TIME_STAMP       V9
#define VPIN_DEEP_SLEEP       V12
#define VPIN_BLYNK_MESSAGE    V15

#include "BlynkEdgent.h"
#include <TimeLib.h>
#include <WidgetRTC.h>

//NODE MCU
static const uint8_t D1 = 5;  //SAFE PIN - LOW ON BOOT =
const int sensorPin = A0;
const int motorRelay = D1 ; 
String txt;
int sensorLimit = 850;
int sensorValue = 0 ;
const int buff_size_sv = 5; //taking last 5
long arr_sv[buff_size_sv];
bool firstRun = false;
bool motorFlag = false;
bool water_detected = false;
unsigned long startMilliSec_nowater = millis();
unsigned long startMilliSec_tempstart = millis();
unsigned long startmills_setupdone = millis() ;
unsigned long firstRunTimeout = 5UL * 60UL * 1000UL;      // default 5 minutes
unsigned long waitBeforeOff_nowater = 30UL * 1000UL;      // default 30 seconds
bool nowater_flag = false;
unsigned long motorStartTimeMillis ;
unsigned long motorEndTimeMillis ;
unsigned long motorTotalMillis ;
unsigned long lastMotorTotalMillis ;
unsigned long timeout_forceStart = 5UL * 60UL * 1000UL;   // 5 minutes
String lastReading = "";
String timeStamp;
bool forceStart = false;
bool tempOff = false;
bool blynkMsg = false;  
const int BLYNK_MAX_CYCLE = 2; 
int blynkMsgCounter = BLYNK_MAX_CYCLE; 
bool firstConnect = false;
bool runOnceClock = false;
bool runFirst = false;
int runFirstCounter = 0;
bool runLast = false;
int deepSleepCounter = 0 ;
bool deepSleep = false;
int lastSV = -1;
int lastMotor = -1;
String lastTxt = "NULL";


BlynkTimer timer;
WidgetRTC rtc;

BLYNK_CONNECTED(){
  if (!firstConnect) {
    Blynk.virtualWrite(VPIN_MOTOR_STATUS, 0 );  
    Blynk.virtualWrite(VPIN_SV_VALUE, 0 );  
    Blynk.virtualWrite(VPIN_INFO,  "SETUP DONE" );
    firstConnect = true;
  }
  Blynk.syncVirtual(VPIN_TEMP_OFF);  // TEMP OFF
  Blynk.syncVirtual(VPIN_MOTOR_STATUS);  //M1  STATUS
  Blynk.syncVirtual(VPIN_SV_VALUE);  //M1 SV VALUE
  Blynk.syncVirtual(VPIN_SV_LIMIT);  //M1 SL LIMIT
  Blynk.syncVirtual(VPIN_INFO);  //INFO DISPLAY
  Blynk.syncVirtual(VPIN_WAIT_BEFORE_OFF);  // wait before off
  Blynk.syncVirtual(VPIN_FORCE_START);  // force start
  Blynk.syncVirtual(VPIN_TEMP_RUN_MIN);  // temp run min
  Blynk.syncVirtual(VPIN_TIME_STAMP); 
  Blynk.syncVirtual(VPIN_DEEP_SLEEP);  // Deep Sleep  
  Blynk.syncVirtual(VPIN_BLYNK_MESSAGE); 
  Blynk.sendInternal("rtc", "sync"); //request current local time for device
}

BLYNK_WRITE(VPIN_TEMP_OFF){  tempOff = param.asInt();}
BLYNK_WRITE(VPIN_SV_LIMIT){ sensorLimit = param.asInt(); }
BLYNK_WRITE(VPIN_WAIT_BEFORE_OFF){  waitBeforeOff_nowater  = (param.asInt()) * 1000UL;}
BLYNK_WRITE(VPIN_FORCE_START){  if (param.asInt()){ forceStart = true; }  else{ forceStart = false;}}
BLYNK_WRITE(VPIN_TEMP_RUN_MIN){ firstRunTimeout =  (param.asInt()) * 60UL * 1000UL;  }
BLYNK_WRITE(VPIN_DEEP_SLEEP){  deepSleep = param.asInt();}
BLYNK_WRITE(VPIN_BLYNK_MESSAGE) {  blynkMsg = param.asInt(); if (!blynkMsg){ blynkMsgCounter = BLYNK_MAX_CYCLE;} }

void setup(){
  Serial.begin(115200);  
  delay(100);  
  BlynkEdgent.begin();

  pinMode(motorRelay, OUTPUT) ;
  digitalWrite(motorRelay , LOW) ;

  //SV DEFAULT VALUES
  for (int i = 0; i < buff_size_sv; i++) {arr_sv[i] = 500;}

  setSyncInterval(2 * 60 * 60);  //2 hour
  timer.setInterval(1000L, runLogic); //1000 = 1 sec

  startmills_setupdone= millis();
}

void runLogic(){
  if ( year() >2020 && !runOnceClock){
    String currentDate = String(day()) + "-" + getMonthStr(month()) + "-" + year();
    Blynk.virtualWrite(VPIN_TIME_STAMP, currentDate + " " + getTimeAMPM());
    runOnceClock = true;
  }

  //if (!motorFlag && lastReading.length()> 5){ txt = lastReading ; }
  //if (!runFirst && millis() - startmills_setupdone >= 60000UL /*AFTER 60 SEC*/ ) {  blynkMsgCounter = 0; runFirst = true;  }
  //if (!runFirst ) {runFirstCounter ++ ; if (runFirstCounter > 2)  {  blynkMsgCounter = 0; runFirst = true;  }}
  if (!runFirst && millis() - startmills_setupdone >= 60000UL) /*1 MIN */ { blynkMsgCounter = 0;    runFirst = true;}
  if (!runLast && !motorFlag && lastReading.length() > 5 )  { txt = lastReading ; blynkMsgCounter = 0; runLast = true;} 

  if (blynkMsg || blynkMsgCounter < BLYNK_MAX_CYCLE) {
    if (!blynkMsg) { blynkMsgCounter++; }
    if (sensorValue != lastSV) {  lastSV = sensorValue; Blynk.virtualWrite(VPIN_SV_VALUE, sensorValue);}
    int motorInt = motorFlag ? 1 : 0;
    if (motorInt != lastMotor) { lastMotor = motorInt; Blynk.virtualWrite(VPIN_MOTOR_STATUS, motorInt); }
    if (txt != lastTxt ) { lastTxt = txt;Blynk.virtualWrite(VPIN_INFO, txt);}
  }
  
  if (tempOff && deepSleep ) {deepSleepCounter++ ; if (deepSleepCounter > 2) { Blynk.disconnect(); delay(100);ESP.deepSleep(0);  }}

  sensorValue = get_avg_sv(analogRead(sensorPin));

  /*TEMP OFF MOTOR*/
  if (tempOff){ 
    firstRun = true ;  
    digitalWrite(motorRelay, LOW);  
    txt = "TEMP OFF";   
  }

  //FIRST RUN AND FORCE START
  else if (!firstRun || forceStart){ 
    txt = "";
    if (sensorValue < sensorLimit && !water_detected){ water_detected = true ; } /*NATURAL WATER*/

    if (!motorFlag) { digitalWrite(motorRelay , HIGH) ; motorFlag = true;  startMilliSec_tempstart = millis() ;  }/*TEMPORARY START MOTOR*/
   
    //if force start is on we cant turn off
    else{
        if (!firstRun) { txt = "TEMP RUN: " + showTimer(startMilliSec_tempstart, false);
        if ((millis() - startMilliSec_tempstart) >= firstRunTimeout) { firstRun = true;  } }  /* FIRST RUN DONE*/

        if (forceStart) { txt = "FORCE START: " + showTimer(startMilliSec_tempstart, false);
        if ((millis() - startMilliSec_tempstart) > timeout_forceStart) { forceStart = false;  } }/* FORCE START DONE*/
    }
  }
  
  else{
    //WATER IS COMING
    if (sensorValue < sensorLimit ) {
      if (!motorFlag)  {    digitalWrite(motorRelay, HIGH);    motorFlag = true ;    water_detected = true ;    motorStartTimeMillis = millis() ;  }
      else if ( motorFlag && nowater_flag){  nowater_flag = false;    }    
      else {txt = "LIVE: " + showTimer(startmills_setupdone, false);      }
    }
    /*STOP MOTOR IF NO WATER*/
    else if (sensorValue > sensorLimit && motorFlag && !forceStart) {      
      if (!water_detected){ digitalWrite(motorRelay, LOW);  motorFlag = false; txt = "NO WATER DTD:" ; }
      else{
        if (!nowater_flag){  nowater_flag = true ; startMilliSec_nowater = millis() ; }
        txt = "NO WATER: " + showReverse(startMilliSec_nowater, waitBeforeOff_nowater) + "SV:" + String(sensorValue)  ;
        if ((millis() - startMilliSec_nowater) > waitBeforeOff_nowater){
          digitalWrite(motorRelay, LOW); //STOP MOTOR 2
          motorFlag = false;
          nowater_flag = false;
          motorEndTimeMillis = millis() ;
          motorTotalMillis = motorEndTimeMillis - motorStartTimeMillis;
          if (lastMotorTotalMillis > 0){ motorTotalMillis += lastMotorTotalMillis ;}
          lastMotorTotalMillis = motorTotalMillis;
          lastReading = "RAN FOR: " + showTimer(motorTotalMillis, true);
          runLast = false;
        }
      }
    }
    else { txt = "STAND BY";}
  }
}

void loop() {  BlynkEdgent.run();  timer.run();}

/* we are taking last x values of the SV value to see the actual status of SV */
int get_avg_sv(int val_sv) {
  static byte i = 0;
  arr_sv[i] = val_sv;
  i = (i + 1) % buff_size_sv;

  long total = 0;
  for (int j = 0; j < buff_size_sv; j++) total += arr_sv[j];
  return total / buff_size_sv;
}

String showReverse(unsigned long startTime, unsigned long durationMs) {
  unsigned long elapsed = millis() - startTime;
  if (elapsed >= durationMs) elapsed = durationMs;  // stop at 0
  unsigned long remaining = durationMs - elapsed;
  unsigned long seconds = (remaining / 1000) % 60;
  unsigned long minutes = (remaining / 60000) % 60;
  unsigned long hours   = (remaining / 3600000) % 24;

  return padZero(hours) + ":" + padZero(minutes) + ":" + padZero(seconds);
}

String showTimer(unsigned long startTime,bool isSummary) {
  unsigned long elapsed;
  if (isSummary)  {       elapsed = startTime;    } /*total time*/
  else {elapsed = millis() - startTime;    } /*start time*/
  unsigned long seconds = (elapsed / 1000) % 60;
  unsigned long minutes = (elapsed / 60000) % 60;
  unsigned long hours   = (elapsed / 3600000) % 24;
  //last_run_minutes = (int)minutes;      // store last minutes
  return padZero(hours) + ":" + padZero(minutes) + ":" + padZero(seconds);
}

String padZero(int val){  if (val < 10){    return "0" + String(val);  }  else{  return String(val);  }}
 
String getMonthStr(int m){  String arr[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };  return arr[m-1];}

String getTimeAMPM() {  int hr = hour();  String ampm = (hr >= 12) ? "PM" : "AM";  if (hr == 0) hr = 12;  else if (hr > 12) hr -= 12;  return String(padZero(hr)) + ":" + padZero(minute()) + " " + ampm;}