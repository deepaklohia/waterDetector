#define BLYNK_TEMPLATE_ID "xxx"
#define BLYNK_TEMPLATE_NAME " xx"
#define BLYNK_FIRMWARE_VERSION "0.0.2"

/*
3-Sept-2024 changed SV to take last 10 values
7-Sept-2024 Changed SV to 5
*/

//#define BLYNK_PRINT Serial
//#define BLYNK_DEBUG
//#define APP_DEBUG

// Uncomment your board, or configure a custom board in Settings.h
//#define USE_SPARKFUN_BLYNK_BOARD
#define USE_NODE_MCU_BOARD
//#define USE_WITTY_CLOUD_BOARD
//#define USE_WEMOS_D1_MINI

#define VPIN_TEMP_OFF         V0
#define VPIN_MOTOR_STATUS     V1
#define VPIN_SV_VALUE         V2
#define VPIN_SV_LIMIT         V3
#define VPIN_INFO             V5
#define VPIN_FORCE_START       V6
#define VPIN_WAIT_BEFORE_OFF  V7
#define VPIN_TIME_STAMP       V9
#define VPIN_FORCE_DAILY      V10
#define VPIN_DAY_CHANGE       V11
#define VPIN_DEEP_SLEEP       V12
#define VPIN_BLYNK_MESSAGE    V15

#include "BlynkEdgent.h"
#include <TimeLib.h>
#include <WidgetRTC.h>
 
//NODE MCU BASED
static const uint8_t D1   = 5; //SAFE PIN LOW ON BOOT 
static const uint8_t D2   = 4; //SAFE PIN LOW ON BOOT
static const uint8_t D5   = 14;

const int buff_size_sv = 10; //taking last 10 values of the SV 
long arr_sv[buff_size_sv];
unsigned long startMilliSec ;

int sensorLimit = 860;
int sensorValue = 0 ;
bool motorFlag = false;
String txt;

int currentYear;
int currentMonth;
int currentDay;
bool motorDay = false;
bool motorDayOriginal ;
String motorDayStr;

unsigned long tme ;
long seconds ;
long minutes ;
long hours ;
long days ;

const int sensorPin = A0;
const int motorRelay = D1 ;
const int pullupAlexaStart = D5 ; 
bool forceDaily = false;
bool dayChange = false;
bool forceStart = false;
bool nowater_flag = false;
unsigned long startMilliSec_noWater = millis();
unsigned long startMilliSec_testRun = millis();
unsigned long startmills_motorStart = millis();
unsigned long startmills_motorStop ;
unsigned long motorTotalMillis ;
unsigned long lastMotorTotalMillis ;
unsigned long startmills_setupdone;
unsigned long waitBeforeOff_nowater = 30UL * 1000UL;      // default 30 seconds
unsigned long timeout_forceStart = 5UL * 60UL * 1000UL;   // 5 minutes
unsigned long deepSleepStartTime = 2UL * 60UL * 1000UL;   // 2 minutes
int deepsleep_counter ;
bool testRun = false;
int lastWaterDay = 7  ;  
int lastWaterMonth = 5 ;  
int lastWaterYear = 2024 ; 
bool tempOff = false;
bool runOnceClock = false;
bool runOnceConnect = false;
bool blynkMsg = false;  
const int BLYNK_MAX_CYCLE = 2; 
int blynkMsgCounter = BLYNK_MAX_CYCLE; 
int deepSleepCounter = 0 ;
bool deepSleep = true;
bool lastMotorFlag = false;
int lastSensorValue = -1;
String lastTxt = "NULL";
bool timeCalc = false;
bool runFirst = false ;
bool runLast = false;
String lastReading = "";

BlynkTimer timer;
WidgetRTC rtc;

BLYNK_CONNECTED(){
  if (!runOnceConnect) {
    Blynk.virtualWrite(VPIN_MOTOR_STATUS, 0);
    Blynk.virtualWrite(VPIN_SV_VALUE, 0); 
    Blynk.virtualWrite(VPIN_INFO,  "<SETUP DONE>" );
    runOnceConnect = true;
  }
  Blynk.syncVirtual(VPIN_TEMP_OFF);  //TEMP OFF
  Blynk.syncVirtual(VPIN_MOTOR_STATUS);  //M1 / M2 MOTOR STATUS
  Blynk.syncVirtual(VPIN_SV_VALUE);  //M2 /M2 SV VALUE
  Blynk.syncVirtual(VPIN_SV_LIMIT);  //M2 SV LIMIT
  Blynk.syncVirtual(VPIN_INFO);  //INFO DISPLAY
  Blynk.syncVirtual(VPIN_FORCE_DAILY);  //Force Daily
  Blynk.syncVirtual(VPIN_DAY_CHANGE);  //Value Day Change
  Blynk.syncVirtual(VPIN_FORCE_START);  //TEMP START
  Blynk.syncVirtual(VPIN_WAIT_BEFORE_OFF);  //wait before off
  Blynk.syncVirtual(VPIN_TIME_STAMP); 
  Blynk.syncVirtual(VPIN_DEEP_SLEEP);  // Deep Sleep  
  Blynk.syncVirtual(VPIN_BLYNK_MESSAGE); 
  Blynk.sendInternal("rtc", "sync"); //request current local time for device
}

BLYNK_WRITE(VPIN_SV_LIMIT){  sensorLimit = param.asInt();}
BLYNK_WRITE(VPIN_FORCE_DAILY){  forceDaily = param.asInt(); blynkMsgCounter = 0 ; /*show value once */}
BLYNK_WRITE(VPIN_DAY_CHANGE){  dayChange = param.asInt(); blynkMsgCounter = 0 ; /*show value once */ }
BLYNK_WRITE(VPIN_FORCE_START){  forceStart = param.asInt();}
BLYNK_WRITE(VPIN_WAIT_BEFORE_OFF){ waitBeforeOff_nowater  = (param.asInt()) * 1000UL;}
BLYNK_WRITE(VPIN_TEMP_OFF){  tempOff = param.asInt();}
BLYNK_WRITE(VPIN_DEEP_SLEEP){  deepSleep = param.asInt();}
BLYNK_WRITE(VPIN_BLYNK_MESSAGE) {  blynkMsg = param.asInt(); if (!blynkMsg){ blynkMsgCounter = BLYNK_MAX_CYCLE; /*no extra message */} }

void setup(){
  //Serial.begin(115200);
  delay(100);
  BlynkEdgent.begin();

  // This delay gives the chance to wait for a Serial Monitor without blocking if none is found
  delay(1500); 

  pinMode(motorRelay, OUTPUT) ;
  pinMode(pullupAlexaStart, INPUT_PULLUP) ;
  digitalWrite(motorRelay,LOW) ;
  
  //SV DEFAULT VALUES
  for (int i = 0; i < buff_size_sv; i++) {    arr_sv[i] = 1000;  }

  blynkMsgCounter =  BLYNK_MAX_CYCLE ;
  startmills_setupdone= millis();

  setSyncInterval(2 * 60 * 60); // Sync interval in seconds (1 minutes)
  timer.setInterval(1000L, runLogic); //1000 = 1 SEC
}

void loop() {  BlynkEdgent.run();  timer.run();}

void runLogic(){
  if (!runOnceClock) {
    if (year() > 2020) {
      updateMotorDayInfo();
      String currentDate = String(day()) + "-" + getMonthStr(month()) + "-" +  String( year()).substring(2) ;    Blynk.virtualWrite(VPIN_TIME_STAMP, currentDate + " " + getTimeAMPM() + " " + 
      "(LD: "       + String(lastWaterDay) + "-"       + getMonthStr(lastWaterMonth) + "-"       + String(lastWaterYear).substring(2) + ")"       ) ;
      runOnceClock = true; 
    }
  }
  else {
    if (!runFirst && millis() - startmills_setupdone >= 60000UL) /*1 MIN */ { blynkMsgCounter = 0;    runFirst = true;}
    if (!runLast && !motorFlag && lastReading.length() > 5 )  { txt = lastReading ; blynkMsgCounter = 0; runLast = true;} 
    
    if (forceDaily) { motorDay = true; } 
    else { motorDay = dayChange ? !motorDayOriginal : motorDayOriginal; }
    motorDayStr = motorDay ? "YES" : "NO";

    /*TURN OFF SYSTEM IF NOT MOTOR DAY*/
    if (!motorDay && !motorFlag && deepSleep) {
      if  (millis() - startmills_setupdone >= deepSleepStartTime) { 
        txt = "<DEEP SLEEP>"; blynkMsgCounter = 0; deepSleepCounter++ ;  if (deepSleepCounter > 2) {Blynk.disconnect();delay(100);ESP.deepSleep(0);}
      }
    }
  }

  if (tempOff){ 
    digitalWrite(motorRelay, LOW);     motorFlag = false;    txt = "TEMP OFF";   
    if (deepSleep && !motorFlag ) {    deepSleepCounter++ ;    if (deepSleepCounter > 2) {      Blynk.disconnect();      delay(100);      ESP.deepSleep(0);     }  }  
  }

  if (!nowater_flag && txt.length() > 0 && txt.indexOf("DY:") == -1) {
    txt += " DY:" + motorDayStr;
  }

  if (blynkMsg || blynkMsgCounter < BLYNK_MAX_CYCLE) {
    if (!blynkMsg) { blynkMsgCounter++; }
    if (motorFlag != lastMotorFlag) {Blynk.virtualWrite(VPIN_MOTOR_STATUS, motorFlag ? 1 : 0);lastMotorFlag = motorFlag;    }
    if (sensorValue != lastSensorValue) {Blynk.virtualWrite(VPIN_SV_VALUE, sensorValue);lastSensorValue = sensorValue;    }
    if (txt != lastTxt) {Blynk.virtualWrite(VPIN_INFO, txt);lastTxt = txt;}
  }

  sensorValue = get_avg_sv(analogRead(sensorPin));
  int externalPullup = digitalRead(pullupAlexaStart);

 //AUTO DETECT WATER
  if (sensorValue < sensorLimit){
    //txt = "" ;
    if (!motorFlag){
      digitalWrite(motorRelay, HIGH);
      motorFlag = true ; 
      txt = "WATER DTD";
      startmills_motorStart = millis();
      blynkMsgCounter = 0 ;
    }
    else if (testRun){testRun = false;startmills_motorStart = millis();} /*REST TEST RUN*/
    else{ txt = "LIVE:" + showTimer(startmills_motorStart, false) ;  if (nowater_flag  ){ nowater_flag = false;} /*NO WATER RESET*/}
  }
  //IF FORCE START IS ON 
  else if ( forceStart ||  (externalPullup == 0 && ((motorDay )))) {
    if (!motorFlag){
      testRun = true;
      digitalWrite(motorRelay, HIGH); 
      motorFlag = true;
      startMilliSec_testRun = millis();
    }
    else {
      if (forceStart){ txt = "FRC: ";   }   else{  txt = "TEST: ";   }
      txt = txt + showTimer(startMilliSec_testRun, false) ;  

      if ((millis() - startMilliSec_testRun) > timeout_forceStart){ forceStart = false; txt = "FORCE START TIMEOUT";  } /*FORCE START SAFETY*/
    }
  }

  //WAIT BEFORE OFF
  else if ((sensorValue > sensorLimit && motorFlag && !forceStart) && (externalPullup == 1 || (externalPullup == 0 && !motorDay ))){
    /*IF NOT TEST RUN THEN WAIT */
    if (!testRun){
      if (!nowater_flag){
        nowater_flag = true ;
        startMilliSec_noWater = millis() ;
      }
      //txt = "NO WATER: " + showReverseTimer(startMilliSec_noWater, waitBeforeOff_nowater) + " SV:" + String(sensorValue);
      txt = "NO WATER: " + showReverseTimer(startMilliSec_noWater, waitBeforeOff_nowater) ;
      if ((millis() - startMilliSec_noWater) > waitBeforeOff_nowater){
        digitalWrite(motorRelay, LOW); //STOP MOTOR
        motorFlag = false;
        nowater_flag = false;
        startmills_motorStop = millis() ;
        motorTotalMillis = startmills_motorStop - startmills_motorStart;
        if (lastMotorTotalMillis > 0){ motorTotalMillis += lastMotorTotalMillis ;}
        lastMotorTotalMillis = motorTotalMillis;
        lastReading = "RAN FOR: " + showTimer(motorTotalMillis, true);
        runLast = false; /*CAPTURE READING IN BLYNK*/
        //blynkMsgCounter = 0;
      }
    }
    /*IF IT WAS TEST RUN THEN IMMEDIATELY OFF*/
    else{
      digitalWrite(motorRelay, LOW); //STOP MOTOR 
      motorFlag = false;
      testRun = false;
      txt = "NO WTR DTD";
    }
  }
  else {
    if (lastReading.length() > 5) { txt = "<SB> " + lastReading ;  }
    else {txt = "<STAND BY>" ; }
  }
}

/* we are taking last x values of the SV value to see the actual status of SV */
int get_avg_sv(int val_sv)
{
  long total = 0;
  byte count = 0;
  static byte i_sv = 0;
 
  arr_sv[i_sv++] = val_sv;
  if (i_sv == buff_size_sv){ i_sv = 0;}
  
  while (count < buff_size_sv) {
    total = total + arr_sv[i_sv++];
    if (i_sv == buff_size_sv){i_sv = 0;}
    count++;
  }
  return total/buff_size_sv;
}

void updateMotorDayInfo(){
  currentYear = year();
  currentMonth = month();
  currentDay = day();

  int daydiff = dayDiff_TL(   lastWaterDay,    lastWaterMonth,lastWaterYear,         currentDay,    currentMonth,    currentYear    );
  int dayRem = daydiff % 2 ;
  if (dayRem != 0){ motorDayOriginal =  false;} 
  else {  motorDayOriginal =  true; }  

  motorDay = motorDayOriginal ;  
}

/* convert date to timestamp */
time_t makeDate(int d, int m, int y) {  tmElements_t tm;  tm.Day = d;  tm.Month = m;  tm.Year = y - 1970;  tm.Hour = 0;  tm.Minute = 0;  tm.Second = 0;  return makeTime(tm);}

/* difference between two dates */
int dayDiff_TL(int d1, int m1, int y1, int d2, int m2, int y2) {
  time_t t1 = makeDate(d1, m1, y1);
  time_t t2 = makeDate(d2, m2, y2);
  long diffSec = t2 - t1;
  return diffSec / 86400; // days
}

String padZero(int val){  if (val < 10){ return "0" + String(val); }  else{ return String(val); }}

String getMonthStr(int m){  String arr[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };  return arr[m-1];}

String getTimeAMPM() {  int hr = hour();  String ampm = (hr >= 12) ? "PM" : "AM";  if (hr == 0) hr = 12;  else if (hr > 12) hr -= 12;  return String(padZero(hr)) + ":" + padZero(minute()) + " " + ampm;}

String showReverseTimer(unsigned long startTime, unsigned long durationMs) {
  unsigned long elapsed = millis() - startTime;
  if (elapsed >= durationMs) elapsed = durationMs;  // stop at 0
  unsigned long remaining = durationMs - elapsed;
  unsigned long seconds = (remaining / 1000) % 60;
  unsigned long minutes = (remaining / 60000) % 60;
  unsigned long hours   = (remaining / 3600000) % 24;

  return padZero(hours) + ":" + padZero(minutes) + ":" + padZero(seconds);
}

String showTimer(unsigned long startTime,bool isSummary) {
  unsigned long elapsed;
  if (isSummary)  {       elapsed = startTime;    } /*total time*/
  else {elapsed = millis() - startTime;    } /*start time*/
  unsigned long seconds = (elapsed / 1000) % 60;
  unsigned long minutes = (elapsed / 60000) % 60;
  unsigned long hours   = (elapsed / 3600000) % 24;
  //last_run_minutes = (int)minutes;      // store last minutes
  return padZero(hours) + ":" + padZero(minutes) + ":" + padZero(seconds);
}